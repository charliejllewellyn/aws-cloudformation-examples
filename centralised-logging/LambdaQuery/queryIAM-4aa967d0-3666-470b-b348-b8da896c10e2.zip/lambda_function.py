import boto3
import os
import json

client = boto3.client('iam')

def listUsers():
    response = client.list_users()
    return response['Users']
    
def checkMfa():
    users = listUsers()
    noMfaList = []
    for user in users:
        if not client.list_mfa_devices(UserName=user['UserName'])['MFADevices']:
            noMfaList.append(user['UserName'])
    return noMfaList
            
def postSns():
    sns = boto3.client('sns')
    response = sns.publish(
        TargetArn=os.environ.get("SNS_TOPIC"),
        Message=json.dumps({'default': json.dumps(checkMfa())}),
        MessageStructure='json')

def lambda_handler(event, context):
    postSns()
    # TODO implement
    return 'Hello from Lambda'
